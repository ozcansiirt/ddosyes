##############################################
#             PLANETWORK-DDOS                #
#           Created by : Hydra7              #
#               ----------                   #
#        Dark-IT & PLANETWORK TeaM           #
##############################################

#install
git clone https://github.com/Hydra7/Planetwork-DDOS
cd Planetwork-DDOS
python2 ./pntddos.py

#Usage
Sebelum menggunakan Tool ini sebaiknya cari dulu alamat IP dari Korban dan scan dimana port yang terbuka

lalu ketikkan:
python2 ./pntddos.py ip port packet

contoh:
python2 ./pntddos.py 192.168.xx.xx 80 3000

#Note
Tools ini hanya sebagai pembelajaran untuk serangan DOS & DDOS
ingat ya, ddos hanyalah sebagian kecil dan sangat kecil dari dunia hacking
jadi jangan bangga kalo cuma bisa ddos doang

INGAT!! JANGAN MELAKUKAN SERANGAN DOS/DDOS TANPA MENGGUNAKAN JARINGAN WIFI!!!!


#Kunjungi
Forum : https://forum.gorontalodarkit.com
IRC   : irc.planetwork.id

#Greetz
Dark-IT & plaNETWORK TeaM
