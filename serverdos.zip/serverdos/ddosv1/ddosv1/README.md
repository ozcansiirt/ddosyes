
DDOSV1

==============

Ddosv1 is an python app for SECURITY TESTING PURPOSES ONLY!

Ddosv1 is a HTTP DdoS Test Tool. 

Attack Vector exploited: HTTP Keep Alive + NoCache

Usage

------------------------------------------------------------------------
open cmd
change directory
after
PATH\python.exe ddosv1.py
------------------------------------------------------------------------

Changelog

------------------------------------------------------------------------
------------------------------------------------------------------------


License

------------------------------------------------------------------------
------------------------------------------------------------------------


LEGAL NOTICE 

------------------------------------------------------------------------
THIS SOFTWARE IS PROVIDED FOR EDUCATIONAL USE ONLY! IF YOU ENGAGE IN ANY ILLEGAL ACTIVITY THE AUTHOR DOES NOT TAKE ANY RESPONSIBILITY FOR IT. BY USING THIS SOFTWARE YOU AGREE WITH THESE TERMS.
------------------------------------------------------------------------
